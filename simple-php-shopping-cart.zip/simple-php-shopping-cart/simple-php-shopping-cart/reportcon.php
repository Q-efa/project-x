<?PHP
$connect=mysqli_connect("localhost","root","test");
$con=mysqli_select_db($connect,"online_shop" );
?>