<?PHP
include_once('reportcon.php');
?>
<!doctype html>
<html>
	<head>
		<title>Report</title>
		<link rel="stylesheet" type="text/css" href="css/style.css"/>

	</head>
	<body>
		<div class="container">
			<div class="wrapper">
			<h1><center> Product Report</center></h1><br><br>
		</div>
		<div class="data">
		<form action ="report.php" method="POST">
		<select name="tblproduct">
		<option>select</option>
		<?PHP
		$query1="SELECT * FROM  tblproduct";
		$result=msql_query($query1);
		while($numRows = mysql_fetch_array ($result)){
			$stardardname=$rows1['name'];
		}
		
		?>
		<option value="<?PHP echo $stardardname;?>"></option>
		</select><br><BR>
		<div class="buttons">
		<input type="submit" name="submit" class="buttons"/>
		</div>
		
		<div class="table"></div>
			<table border="1" class="table">
			<tr>
				<th>product</th>
				<th>price</th>
				</tr>
				</table>
				</form>
			</div>
		</div>
	</body>	
</html>