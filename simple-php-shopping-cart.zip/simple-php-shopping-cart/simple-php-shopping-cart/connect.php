<?PHP
$mysql_host='localhost';
$mysql_user='root';
$mysql_password='test';
mysql_connect($mysql_host,$mysql_user,$mysql_password);
echo 'connection success';
?>